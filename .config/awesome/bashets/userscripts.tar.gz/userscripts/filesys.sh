FSU=`df -h $1 | awk '{print $5}' | tail -n 1`
echo -n $FSU
