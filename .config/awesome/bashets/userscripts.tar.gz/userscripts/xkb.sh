#!/bin/bash

echo -n `getxkblayout` | tr '[:lower:]' '[:upper:]'
